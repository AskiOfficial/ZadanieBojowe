let selectedQuestion = -1;

function selectQuestion(id)
{
    
}

/*for(let i = 0; i < 20; i++)
{
    let pytanie = Math.floor(Math.random() * QuestionsKeys.length);
    console.log(pytanie);
    QuestionsPanel.innerHTML += QuestionsKeys[pytanie];
}*/